﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
namespace myfirst_api.Models
{
    public class db_repository
    {
        string constring = "server=pc251447;database=dreamhome;integrated security=false;user id=sa;password=password-1";
        public List<string> populate_branch()
        {
            List<string> branchno = new List<string>();
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            string qry = "select branchno from branch";
            SqlCommand cmd = new SqlCommand(qry, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
               // dr[0].ToString();
                branchno.Add(dr[0].ToString());
            }

            return branchno;
        }

        public branch get_details( string  brno)
        {
            branch b=new branch();
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            string qry = "select * from branch where branchno=@brno";
            
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType=CommandType.Text;
            cmd.CommandText=qry;
            cmd.Parameters.AddWithValue("@brno", brno);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                b.branchno = dr[0].ToString();
                b.street = dr[1].ToString();
                b.city = dr[2].ToString();
                b.postcode = dr[3].ToString();

            }
            return b;
        }

        public string add_branch(branch br)
        {
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            string qry = "insert into branch values (@bno,@street,@city,@postcode)";
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = qry;
            cmd.Parameters.AddWithValue("@bno", br.branchno);
            cmd.Parameters.AddWithValue("@street", br.street);
            cmd.Parameters.AddWithValue("@city", br.city);
            cmd.Parameters.AddWithValue("@postcode", br.postcode);
            int i= cmd.ExecuteNonQuery();
            if (i == 1)
            {
                return ("branch added successfully");
            }
            else
            {
                return "error in inserting";
            }

        }
        public int remove_branch(string bno)
        {
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            string qry = "delete from branch where branchno=@bno";
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = qry;
            cmd.Parameters.AddWithValue("@bno", bno);
            int i = cmd.ExecuteNonQuery();
            return i;            
        }
        public int update_branch(branch br)
        {
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            string qry = "update branch set street=@street,city=@city,postcode=@postcode where branchno=@branchno";
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = qry;
            cmd.Parameters.AddWithValue("@branchno", br.branchno);
            cmd.Parameters.AddWithValue("@street",br.street);
            cmd.Parameters.AddWithValue("@city", br.city);
            cmd.Parameters.AddWithValue("@postcode", br.postcode);
            int i = cmd.ExecuteNonQuery();
            return i;     
        }
    }
}