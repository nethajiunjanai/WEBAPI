﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using myfirst_api.Models;

namespace myfirst_api.Controllers
{
    public class branchController : ApiController
    {
        db_repository db = new db_repository();
        public string[] getall_branchno()
        {
            string[] branches = db.populate_branch().ToArray();
            return branches;
        }

        public branch getdetails(string bno)
        {
            branch br=db.get_details(bno);
            return br;

        }

        [HttpPost]
        public string add_branch(branch br)
        {
            string st = db.add_branch(br);
            return st;
        }

        [HttpDelete]
        public int remove(string bno)
        {
            int i = db.remove_branch(bno);
            return i;
        }

        [HttpPut]
        public int update(branch br)
        {
            int i = db.update_branch(br);
            return i;
        }
    }
}
