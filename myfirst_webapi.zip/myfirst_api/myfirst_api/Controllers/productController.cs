﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using myfirst_api.Models;
namespace myfirst_api.Controllers
{
    public class productController : ApiController
    {
        [HttpPost]
        public product showproduct_info(product pr)
        {
            return (pr);
        }
    }
}
