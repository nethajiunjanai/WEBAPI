﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace myfirst_api.Controllers
{
    public class sampleController : Controller
    {
        //
        // GET: /sample/

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult showcolor()
        {
            return View();
        }
        public ActionResult display()
        {
            return View();
        }
    }
}
