﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace myfirst_api.Controllers
{
    public class branch_manipulateController : Controller
    {
        //
        // GET: /branch_manipulate/

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult insertbranch()
        {
            return View();
        }
        public ActionResult removebranch()
        {
            return View();
        }
        public ActionResult updatebranch()
        {
            return View();
        }
    }
}
