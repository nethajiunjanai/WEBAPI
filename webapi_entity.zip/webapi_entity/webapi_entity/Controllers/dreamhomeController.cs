﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using webapi_entity.Models;

namespace webapi_entity.Controllers
{
    public class dreamhomeController : ApiController
    {
        dreamhomeEntities dh = new dreamhomeEntities();

        [HttpGet]
        public List<string> getall_branch()
        {
            
            
            List<string> str = (from s in dh.branches select s.branchNo).ToList();
            return str;
        }

        [HttpGet]
        public List<branch> getbranch()
        {
            
            return dh.branches.ToList();
        }

       // [HttpPost]
        public int insert_branch(branch br)
        {
            dh.branches.Add(br);
            int res = dh.SaveChanges();
            return res;
        }

        public int delete_branch(string bno)
        {
            branch res = (from s in dh.branches where s.branchNo == bno select s).FirstOrDefault();
            //branch res = dh.branches.Where(c => c.branchNo ==bno).Select(c => c).FirstOrDefault();
            dh.branches.Remove(res);
          int i=  dh.SaveChanges();
          return i;
        }

        [HttpPut]
        public int edit_branch(branch br)
        {
            branch update = (from s in dh.branches where s.branchNo == br.branchNo select s).FirstOrDefault();
            update.street = br.street;
            update.city = br.city;
            update.postcode = br.postcode;
            int i = dh.SaveChanges();
            return i;
        }
        [HttpGet]
        public branch showbranch(string bno)
        {
            branch br = (from s in dh.branches where s.branchNo == bno select s).FirstOrDefault();
            return br;
        }
    }
}
