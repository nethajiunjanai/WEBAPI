﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace webapi_entity.Controllers
{
    public class branchController : Controller
    {
        //
        // GET: /branch/

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult add_branch()
        {
            return View();
        }

        public ActionResult delete_branch()
        {
            return View();
        }
        public ActionResult edit_branch()
        {
            return View();
        }
        public ActionResult populate()
        {
            return View();
        }
    }
}
